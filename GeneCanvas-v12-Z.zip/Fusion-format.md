# V11 project extension / 项目扩展

The project retains `version: 1` and the legacy gene fields `fusion`, `color`, `color2`, `split`. 新字段均为可选；旧项目仍可读取。V10 and earlier do not preserve the new fields.

```json
{
  "fusion": true,
  "fusionLabelMode": "segments",
  "segments": [
    {"name": "partA", "color": "#edb758", "weight": 1, "labelX": 0, "labelY": 0},
    {"name": "partB", "color": "#77c69d", "weight": 2, "labelX": 0, "labelY": 0},
    {"name": "partC", "color": "#41b8ae", "weight": 1, "labelX": 0, "labelY": 0}
  ]
}
```

This is an extension fragment, not a complete gene or project. 此片段仅展示新增字段，完整基因还需要原来的位置、长度、名称等属性。

- `segments`: 2–20 elements, always ordered left to right on screen / 按画面从左到右排列。
- `name`: up to 100 characters; empty hides that label / 最多 100 字符，空则不显示。
- `color`: six-digit hexadecimal color / 六位十六进制颜色。
- `weight`: finite number in [0.001, 1000000]. Width = gene width × weight / sum(weights) / 相对宽度权重。
- `labelX`, `labelY`: optional offsets in [-200, 200], default zero / 文字位置偏移，默认零。
- `fusionLabelMode`: `whole`, `segments`, or `both`; absent means `whole` / 总名称、分段名称、两者均显示。

Segment labels inherit gene font, size, italic and angle. Their offsets are independent. 区段标签继承基因字体、字号、斜体和角度，位置独立。

If segments are absent, legacy two-color rendering remains. Editing initializes two segments from `color`, `color2`, `split`, with empty segment names and mode `whole`. 多段设置的权威数据是 `segments`；原双色字段为兼容旧结构保留，不能表示第三段及以后的内容。

Track reversal reverses segment order and mirrors label X offsets. Duplicate, Undo, project save/load and vector/raster export preserve segments. 关闭融合只影响显示，保留分段数据；源基因组坐标不受改变。
