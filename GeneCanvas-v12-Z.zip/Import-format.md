# GeneCanvas table format v1 / 基因表格式

One row per gene; group by `strain_id` and `contig_id`. 一行一个基因，同一菌株的同一 contig 合成一条排列。

| Column / 列名 | Required / 必填 | Meaning / 含义 |
|---|---|---|
| strain_id | Yes / 是 | Stable strain name / 菌株标识 |
| contig_id | Yes / 是 | Contig identifier / 片段编号 |
| start | Yes / 是 | 1-based inclusive start / 起点，包含该碱基 |
| end | Yes / 是 | Inclusive end, >= start / 终点，不小于起点 |
| strand | Yes / 是 | `+` or `-` / 正负链 |
| gene | Yes / 是 | Label or `UNKNOWN` / 基因名或未知 |
| length_bp | No / 否 | Must equal end-start+1 / 如填写须与坐标一致 |
| gene_id | No / 否 | Optional record identifier / 可选记录编号 |
| tree_tip | No / 否 | Exact tree tip name; consistent within a strain / 树末端名称，同菌株应一致 |
| color | No / 否 | `#RRGGBB`; consistent for the same gene / 同名基因配色应一致 |

Supported files: XLSX, CSV and TSV. 推荐使用以上英文列名，两个语言版本也都兼容原中文表头。Optional empty cells are treated as absent. 空的可选单元格视为未提供。

UNKNOWN is white and unlabeled. Gene names are matched case-insensitively for automatic colors. 多 contig 始终分行；紧凑模式可以缩短长间隔，但 `//` 由用户手动添加。

Fusion structure is intentionally not inferred from a combined name or comma. 融合分段需要在界面中编辑；完整图形保存在项目 JSON 中。
