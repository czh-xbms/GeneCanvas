# V12 — Rotate children / 旋转子节点

## 使用

在左侧“系统发育树”展开“旋转子节点（局部分叉）”。勾选“在树上选择分叉”，点击画布中的节点圆点；也可直接在“目标分叉”下拉框选择。

“旋转子节点：反转上下顺序”仅反转该节点的直接子分支。二分叉交换两个子分支；多分叉反转整个子列表，也可以通过列表中的 ↑ / ↓ 单独调换邻接子分支。子分支内部顺序保持不变。整组基因排列随对应末端移动，同一菌株的多条 contig 保持在一起。

可恢复当前分叉，也可清除所有手动顺序；支持撤销、重做、保存项目和导出 Newick。节点圆点仅用于编辑，不出现在 SVG、PDF、TIFF 或 PNG 中。

手动顺序在 Leaf sort 和整体反转排序之后应用，因此已手动调整的分叉优先采用手动顺序。要使全树重新完全服从 Leaf sort，请先清除全部手动顺序。

筛选只隐藏末端，不删除它们的顺序。改根后，原分叉及其直接子分支集合仍一致的调整继续生效；不再匹配的调整暂时保留而不应用，恢复原根后可以重新生效。“恢复原树根与原始顺序”会清除所有手动顺序。

新项目请使用 V12 或后续兼容版本打开；旧版软件无法保存本功能字段。

## Usage

Expand **Rotate children (selected node)** in the left tree panel. Enable **Pick a node on the tree** and click a node circle, or select a node from the dropdown.

**Rotate children: reverse order** reverses only the selected node's immediate children. Binary nodes swap their two children. Multifurcations reverse their child list; the up/down buttons move individual children. Internal order within each child subtree is unchanged. Gene tracks follow their tips, and multiple contigs of a strain remain together.

Reset one node or clear all manual orders. Undo, Redo, project JSON and Newick export are supported. Node handles appear only in the editor and are excluded from all figure exports.

Manual orders apply after global Leaf sort and inversion. Clear manual orders to make all nodes follow the global sort again. Filtering retains the order of hidden tips. After rerooting, an order is active only if the node and its immediate child groups still match; unmatched orders remain dormant and can reactivate when the original root is restored. Restore root and original order clears manual orders.

Use V12 or a compatible later version for projects with manual node orders.

## Data model

The original `tree.newick` remains unchanged. `tree.childOrders` is an optional array of overrides. Each node and child is identified by its complete, sorted set of descendant tip names, not by internal labels (which may be nonunique support values) or screen coordinates.

```json
{
  "childOrders": [
    {
      "node": ["A", "B", "C"],
      "children": [["C"], ["A", "B"]]
    }
  ]
}
```

This is a fragment of the tree settings, not a complete project. Each entry partitions the node tip set into two or more disjoint, nonempty child sets. Their array order is the requested screen order. An override is applied only when it matches the actual children exactly; it cannot create a clade, move a tip between parents or change a branch length. Node selection and handle visibility are temporary editor state and are not saved.

验证覆盖：二分叉与多分叉、内部支持度标签和分支长度、所有末端对距离、同菌株多 contig、Leaf sort 优先级、筛选、改根和恢复、撤销重做、保存载入、Newick 导出、节点选择及无控制点的图像导出。浏览器真实界面仍未人工验收。
